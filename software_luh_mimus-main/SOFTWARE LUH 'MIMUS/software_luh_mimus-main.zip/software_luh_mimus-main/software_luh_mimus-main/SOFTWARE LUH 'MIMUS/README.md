# Free Bootstrap 5 HTML5 Admin Dashboard Template

Template is a minimalistic Free Bootstrap 5 Template for Admin Dashboard. This theme got no jQuery dependency which will free you from all the excess burden. Instead of working from scratch, you can now save yourself plenty of time and resources with