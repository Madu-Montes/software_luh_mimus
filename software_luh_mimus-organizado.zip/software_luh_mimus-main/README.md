# software_luh_mimus
 Software de gerenciamento desenvolvido para a confeitaria Luh Mimu's - TCC em DS gp01 2022
